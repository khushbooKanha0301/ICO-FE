import React from "react";

export const HomeIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M14.25 19.5V15C14.25 14.8011 14.171 14.6103 14.0303 14.4697C13.8897 14.329 13.6989 14.25 13.5 14.25H10.5C10.3011 14.25 10.1103 14.329 9.96967 14.4697C9.82902 14.6103 9.75 14.8011 9.75 15V19.5C9.75 19.6989 9.67098 19.8897 9.53033 20.0303C9.38968 20.171 9.19891 20.25 9 20.25H4.5C4.30109 20.25 4.11032 20.171 3.96967 20.0303C3.82902 19.8897 3.75 19.6989 3.75 19.5V10.8281C3.75168 10.7243 3.77411 10.6219 3.81597 10.5269C3.85783 10.432 3.91828 10.3463 3.99375 10.275L11.4937 3.45939C11.632 3.33291 11.8126 3.26276 12 3.26276C12.1874 3.26276 12.368 3.33291 12.5062 3.45939L20.0062 10.275C20.0817 10.3463 20.1422 10.432 20.184 10.5269C20.2259 10.6219 20.2483 10.7243 20.25 10.8281V19.5C20.25 19.6989 20.171 19.8897 20.0303 20.0303C19.8897 20.171 19.6989 20.25 19.5 20.25H15C14.8011 20.25 14.6103 20.171 14.4697 20.0303C14.329 19.8897 14.25 19.6989 14.25 19.5Z"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export const EscrowIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M18.375 20.25C19.8247 20.25 21 19.0747 21 17.625C21 16.1753 19.8247 15 18.375 15C16.9253 15 15.75 16.1753 15.75 17.625C15.75 19.0747 16.9253 20.25 18.375 20.25Z"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M18.375 15V11.2406C18.3734 10.0451 17.8981 8.89893 17.0531 8.05313L13.5 4.5"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M13.5 8.25V4.5H17.25"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M5.625 9C7.07475 9 8.25 7.82475 8.25 6.375C8.25 4.92525 7.07475 3.75 5.625 3.75C4.17525 3.75 3 4.92525 3 6.375C3 7.82475 4.17525 9 5.625 9Z"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M5.625 9V12.7594C5.62662 13.9549 6.10194 15.1011 6.94687 15.9469L10.5 19.5"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M10.5 15.75V19.5H6.75"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export const CalenderIcon = ({width, height}) => {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="-50 -80 200 200" 
      width={width}
      height={height}
      fill="#FFFFFF"
      // style="enable-background:new 0 0 122.88 122.88" 
      >
      <g>
        <path d="M81.61,4.73c0-2.61,2.58-4.73,5.77-4.73s5.77,2.12,5.77,4.73v20.72c0,2.61-2.58,4.73-5.77,4.73s-5.77-2.12-5.77-4.73V4.73 L81.61,4.73z M29.61,4.73c0-2.61,2.58-4.73,5.77-4.73s5.77,2.12,5.77,4.73v20.72c0,2.61-2.58,4.73-5.77,4.73s-5.77-2.12-5.77-4.73 V4.73L29.61,4.73z M6.4,45.32h110.08V21.47c0-0.8-0.33-1.53-0.86-2.07c-0.53-0.53-1.26-0.86-2.07-0.86H103 c-1.77,0-3.2-1.43-3.2-3.2c0-1.77,1.43-3.2,3.2-3.2h10.55c2.57,0,4.9,1.05,6.59,2.74c1.69,1.69,2.74,4.02,2.74,6.59v27.06v65.03 c0,2.57-1.05,4.9-2.74,6.59c-1.69,1.69-4.02,2.74-6.59,2.74H9.33c-2.57,0-4.9-1.05-6.59-2.74C1.05,118.45,0,116.12,0,113.55V48.53 V21.47c0-2.57,1.05-4.9,2.74-6.59c1.69-1.69,4.02-2.74,6.59-2.74H20.6c1.77,0,3.2,1.43,3.2,3.2c0,1.77-1.43,3.2-3.2,3.2H9.33 c-0.8,0-1.53,0.33-2.07,0.86c-0.53,0.53-0.86,1.26-0.86,2.07V45.32L6.4,45.32z M116.48,51.73H6.4v61.82c0,0.8,0.33,1.53,0.86,2.07 c0.53,0.53,1.26,0.86,2.07,0.86h104.22c0.8,0,1.53-0.33,2.07-0.86c0.53-0.53,0.86-1.26,0.86-2.07V51.73L116.48,51.73z M50.43,18.54 c-1.77,0-3.2-1.43-3.2-3.2c0-1.77,1.43-3.2,3.2-3.2h21.49c1.77,0,3.2,1.43,3.2,3.2c0,1.77-1.43,3.2-3.2,3.2H50.43L50.43,18.54z"/>
      </g>
    </svg>
  )
}
export const TradeHistoryIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M7.24487 14.7815L10.238 10.8913L13.6522 13.5732L16.5813 9.79291"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle
        cx="19.9954"
        cy="4.20021"
        r="1.9222"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M14.9245 3.12012H7.65679C4.64535 3.12012 2.77808 5.25284 2.77808 8.26428V16.3467C2.77808 19.3581 4.60874 21.4817 7.65679 21.4817H16.2609C19.2724 21.4817 21.1396 19.3581 21.1396 16.3467V9.30776"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export const QuestionIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M12 21C16.9706 21 21 16.9706 21 12C21 7.02944 16.9706 3 12 3C7.02944 3 3 7.02944 3 12C3 16.9706 7.02944 21 12 21Z"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path d="M12 18C12.5523 18 13 17.5523 13 17C13 16.4477 12.5523 16 12 16C11.4477 16 11 16.4477 11 17C11 17.5523 11.4477 18 12 18Z" />
      <path
        d="M12 13.5V12.75C12.5192 12.75 13.0267 12.596 13.4584 12.3076C13.8901 12.0192 14.2265 11.6092 14.4252 11.1295C14.6239 10.6499 14.6758 10.1221 14.5746 9.61289C14.4733 9.10369 14.2233 8.63596 13.8562 8.26885C13.489 7.90173 13.0213 7.65173 12.5121 7.55044C12.0029 7.44915 11.4751 7.50114 10.9955 7.69982C10.5158 7.8985 10.1058 8.23495 9.81739 8.66663C9.52895 9.09831 9.375 9.60583 9.375 10.125"
        strokeWidth="1.8"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export const NotificationIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 26 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path d="M13.25 11C13.9404 11 14.5 10.4404 14.5 9.75C14.5 9.05964 13.9404 8.5 13.25 8.5C12.5596 8.5 12 9.05964 12 9.75C12 10.4404 12.5596 11 13.25 11Z" />
      <path d="M7.25 11C7.94036 11 8.5 10.4404 8.5 9.75C8.5 9.05964 7.94036 8.5 7.25 8.5C6.55964 8.5 6 9.05964 6 9.75C6 10.4404 6.55964 11 7.25 11Z" />
      <path d="M19.25 11C19.9404 11 20.5 10.4404 20.5 9.75C20.5 9.05964 19.9404 8.5 19.25 8.5C18.5596 8.5 18 9.05964 18 9.75C18 10.4404 18.5596 11 19.25 11Z" />
      <path
        d="M15.7125 19.4875L13.8625 22.575C13.7719 22.7224 13.6451 22.844 13.4941 22.9284C13.3431 23.0129 13.173 23.0572 13 23.0572C12.827 23.0572 12.6569 23.0129 12.5059 22.9284C12.3549 22.844 12.2281 22.7224 12.1375 22.575L10.2875 19.4875C10.2005 19.3393 10.0763 19.2164 9.92723 19.1309C9.77816 19.0454 9.60935 19.0003 9.4375 19H2C1.73478 19 1.48043 18.8946 1.29289 18.7071C1.10536 18.5196 1 18.2652 1 18V2C1 1.73478 1.10536 1.48043 1.29289 1.29289C1.48043 1.10536 1.73478 1 2 1H24C24.2652 1 24.5196 1.10536 24.7071 1.29289C24.8946 1.48043 25 1.73478 25 2V18C25 18.2652 24.8946 18.5196 24.7071 18.7071C24.5196 18.8946 24.2652 19 24 19H16.5625C16.3906 19.0003 16.2218 19.0454 16.0728 19.1309C15.9237 19.2164 15.7995 19.3393 15.7125 19.4875V19.4875Z"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export const BellIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 20 22"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M1.50083 12.7871V12.5681C1.53295 11.9202 1.7406 11.2925 2.10236 10.7496C2.7045 10.0975 3.1167 9.29831 3.29571 8.43598C3.29571 7.7695 3.29571 7.0935 3.35393 6.42703C3.65469 3.21842 6.82728 1 9.96106 1H10.0387C13.1725 1 16.345 3.21842 16.6555 6.42703C16.7137 7.0935 16.6555 7.7695 16.704 8.43598C16.8854 9.3003 17.2972 10.1019 17.8974 10.7591C18.2618 11.2972 18.4698 11.9227 18.4989 12.5681V12.7776C18.5206 13.648 18.2208 14.4968 17.6548 15.1674C16.907 15.9515 15.8921 16.4393 14.8024 16.5384C11.607 16.8812 8.38303 16.8812 5.18762 16.5384C4.09914 16.435 3.08576 15.9479 2.33521 15.1674C1.778 14.4963 1.48224 13.6526 1.50083 12.7871Z"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M7.55493 19.8518C8.05421 20.4785 8.78739 20.884 9.59222 20.9788C10.3971 21.0735 11.2072 20.8495 11.8433 20.3564C12.0389 20.2106 12.2149 20.041 12.3672 19.8518"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export const UserIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 18 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M9 11.25C11.4853 11.25 13.5 9.23528 13.5 6.75C13.5 4.26472 11.4853 2.25 9 2.25C6.51472 2.25 4.5 4.26472 4.5 6.75C4.5 9.23528 6.51472 11.25 9 11.25Z"
        strokeWidth="1.6"
        strokeMiterlimit="10"
      />
      <path
        d="M2.17969 15.1874C2.87081 13.9901 3.86496 12.9958 5.06219 12.3045C6.25941 11.6132 7.61753 11.2493 9 11.2493C10.3825 11.2493 11.7406 11.6132 12.9378 12.3045C14.135 12.9958 15.1292 13.9901 15.8203 15.1874"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export const GreenCheckIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 10 8"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M3.138 5.70803L0.942666 3.6499L0 4.53365L3.138 7.47553L9.60933 1.40865L8.66667 0.524902L3.138 5.70803Z"
        fill="url(#paint0_linear_1_3160)"
      />
      <defs>
        <linearGradient
          id="paint0_linear_1_3160"
          x1="12.6511"
          y1="0.524902"
          x2="-4.91885"
          y2="3.18086"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#7FFC8D" />
          <stop offset="1" stopColor="#C6FA56" />
        </linearGradient>
      </defs>
    </svg>
  );
};
export const RedCrossIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 10 10"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M8.39062 1.80469L2 8.19531"
        stroke="#FE4949"
        strokeWidth="1.5"
        strokeLinecap="square"
        strokeLinejoin="round"
      />
      <path
        d="M8.39062 8.19531L2 1.80469"
        stroke="#FE4949"
        strokeWidth="1.5"
        strokeLinecap="square"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export const CloseIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 32 33"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="check-circle-icon"
    >
      <g clipPath="url(#clip0_1_7731)">
        <path
          d="M16 32.4895C24.8366 32.4895 32 25.3308 32 16.5C32 7.66924 24.8366 0.510498 16 0.510498C7.16344 0.510498 0 7.66924 0 16.5C0 25.3308 7.16344 32.4895 16 32.4895Z"
          fill="#FD5C6D"
        />
        <path
          d="M21.0763 24.0482L23.5508 21.5737L10.9259 8.94881L8.45137 11.4233L21.0763 24.0482Z"
          fill="#010101"
        />
        <path
          d="M10.9268 24.0514L23.5518 11.4265L21.0773 8.95202L8.45234 21.5769L10.9268 24.0514Z"
          fill="#010101"
        />
      </g>
      <defs>
        <clipPath id="clip0_1_7731">
          <rect
            width="32"
            height="32"
            fill="white"
            transform="translate(0 0.5)"
          />
        </clipPath>
      </defs>
    </svg>
  );
};
export const CheckCircleIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      className="check-circle-icon"
      viewBox="0 0 32 33"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g clipPath="url(#clip0_1_7799)">
        <path
          d="M16 32.4895C24.8366 32.4895 32 25.3308 32 16.5C32 7.66924 24.8366 0.510498 16 0.510498C7.16344 0.510498 0 7.66924 0 16.5C0 25.3308 7.16344 32.4895 16 32.4895Z"
          fill="#ADFB69"
        />
        <path
          d="M14.7173 25.005L7.15234 19.1115L9.30334 16.351L13.9488 19.97L21.6158 8.90649L24.4928 10.8995L14.7173 25.005Z"
          fill="black"
        />
      </g>
      <defs>
        <clipPath id="clip0_1_7799">
          <rect
            width="32"
            height="32"
            fill="white"
            transform="translate(0 0.5)"
          />
        </clipPath>
      </defs>
    </svg>
  );
};
export const ExclamationIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 30 29"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="check-circle-icon"
    >
      <path
        d="M15.0002 0.199952C13.1221 0.199295 11.2623 0.568727 9.52705 1.28714C7.79179 2.00555 6.21511 3.05885 4.8871 4.38686C3.55909 5.71487 2.50579 7.29155 1.78738 9.0268C1.06897 10.7621 0.699539 12.6219 0.700196 14.5C0.699539 16.378 1.06897 18.2379 1.78738 19.9731C2.50579 21.7084 3.55909 23.285 4.8871 24.613C6.21511 25.9411 7.79179 26.9944 9.52705 27.7128C11.2623 28.4312 13.1221 28.8006 15.0002 28.8C16.8783 28.8006 18.7381 28.4312 20.4733 27.7128C22.2086 26.9944 23.7853 25.9411 25.1133 24.613C26.4413 23.285 27.4946 21.7084 28.213 19.9731C28.9314 18.2379 29.3009 16.378 29.3002 14.5C29.3009 12.6219 28.9314 10.7621 28.213 9.0268C27.4946 7.29155 26.4413 5.71487 25.1133 4.38686C23.7853 3.05885 22.2086 2.00555 20.4733 1.28714C18.7381 0.568727 16.8783 0.199295 15.0002 0.199952ZM15.0002 24.8C14.5726 24.8009 14.1543 24.675 13.7983 24.438C13.4423 24.201 13.1647 23.8638 13.0006 23.4689C12.8365 23.074 12.7933 22.6393 12.8765 22.2198C12.9596 21.8003 13.1655 21.415 13.4679 21.1126C13.7702 20.8102 14.1556 20.6044 14.575 20.5212C14.9945 20.438 15.4292 20.4812 15.8241 20.6453C16.219 20.8094 16.5563 21.0871 16.7933 21.443C17.0302 21.799 17.1562 22.2173 17.1552 22.645C17.1539 23.2161 16.9264 23.7635 16.5226 24.1673C16.1187 24.5712 15.5713 24.7986 15.0002 24.8ZM17.6152 6.99995L16.8002 18C16.7951 18.076 16.7613 18.1473 16.7056 18.1993C16.6498 18.2513 16.5764 18.2801 16.5002 18.28H13.5002C13.424 18.2801 13.3506 18.2513 13.2948 18.1993C13.2391 18.1473 13.2053 18.076 13.2002 18L12.3852 6.99995C12.3631 6.64294 12.4144 6.28519 12.5358 5.94875C12.6572 5.6123 12.8462 5.30427 13.0912 5.04366C13.3362 4.78304 13.632 4.57535 13.9603 4.43338C14.2886 4.29141 14.6425 4.21816 15.0002 4.21816C15.3579 4.21816 15.7118 4.29141 16.0401 4.43338C16.3684 4.57535 16.6642 4.78304 16.9092 5.04366C17.1542 5.30427 17.3432 5.6123 17.4646 5.94875C17.586 6.28519 17.6373 6.64294 17.6152 6.99995Z"
        fill="#FFC24F"
      />
    </svg>
  );
};
export const SettingIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 18 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M9 12.375C10.864 12.375 12.375 10.864 12.375 9C12.375 7.13604 10.864 5.625 9 5.625C7.13604 5.625 5.625 7.13604 5.625 9C5.625 10.864 7.13604 12.375 9 12.375Z"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M13.8796 5.67417C14.0489 5.91652 14.1971 6.17292 14.3226 6.44058L16.1437 7.45308C16.3711 8.47153 16.3735 9.52734 16.1507 10.5468L14.3226 11.5593C14.1971 11.827 14.0489 12.0834 13.8796 12.3257L13.9148 14.414C13.143 15.1173 12.2295 15.6472 11.2359 15.9679L9.4429 14.8921C9.14796 14.9132 8.8519 14.9132 8.55696 14.8921L6.77102 15.9609C5.77421 15.646 4.85774 15.1182 4.08509 14.414L4.12024 12.3328C3.95238 12.0871 3.80426 11.8284 3.67727 11.5593L1.85618 10.5468C1.62879 9.52837 1.62639 8.47256 1.84915 7.45308L3.67727 6.44058C3.80277 6.17292 3.95097 5.91652 4.12024 5.67417L4.08509 3.58589C4.85687 2.8826 5.77032 2.35275 6.76399 2.03198L8.55696 3.10776C8.8519 3.08667 9.14796 3.08667 9.4429 3.10776L11.2288 2.03901C12.2257 2.35394 13.1421 2.88175 13.9148 3.58589L13.8796 5.67417Z"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export const LogoutIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 18 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g clipPath="url(#clip0_2_611)">
        <path
          fillRule="evenodd"
          clipRule="evenodd"
          d="M7.52992 11.2511C7.94354 11.229 8.29673 11.5464 8.31878 11.9601C8.34887 12.5246 8.38568 12.9717 8.42253 13.3211C8.47202 13.7903 8.76024 14.0754 9.17482 14.1228C9.77006 14.1909 10.6708 14.25 12 14.25C13.3292 14.25 14.23 14.1909 14.8252 14.1228C15.2405 14.0753 15.5279 13.791 15.5774 13.3224C15.664 12.5019 15.75 11.1456 15.75 9C15.75 6.85444 15.664 5.49808 15.5774 4.67756C15.5279 4.20905 15.2405 3.92466 14.8252 3.87719C14.23 3.80914 13.3292 3.75 12 3.75C10.6708 3.75 9.77006 3.80915 9.17482 3.87719C8.76024 3.92458 8.47202 4.20969 8.42253 4.6789C8.38568 5.0283 8.34887 5.47541 8.31878 6.03993C8.29673 6.45355 7.94354 6.77099 7.52992 6.74894C7.11629 6.72689 6.79886 6.3737 6.82091 5.96007C6.85221 5.37295 6.89092 4.8998 6.93081 4.52158C7.04822 3.40827 7.83804 2.52024 9.00446 2.3869C9.66923 2.3109 10.6287 2.25 12 2.25C13.3714 2.25 14.3308 2.3109 14.9956 2.3869C16.1613 2.52015 16.9515 3.40613 17.0691 4.52013C17.1626 5.40604 17.25 6.81691 17.25 9C17.25 11.1831 17.1626 12.594 17.0691 13.4799C16.9515 14.5939 16.1613 15.4798 14.9956 15.6131C14.3308 15.6891 13.3714 15.75 12 15.75C10.6287 15.75 9.66923 15.6891 9.00446 15.6131C7.83804 15.4798 7.04822 14.5917 6.93081 13.4784C6.89092 13.1002 6.85221 12.6271 6.82091 12.0399C6.79886 11.6263 7.11629 11.2731 7.52992 11.2511Z"
          fill="#9F9F9F"
          strokeWidth="0"
        />
        <path
          fillRule="evenodd"
          clipRule="evenodd"
          d="M4.65533 11.0947C4.94822 11.3876 4.94822 11.8624 4.65533 12.1553C4.36244 12.4482 3.88756 12.4482 3.59467 12.1553L0.96967 9.53033C0.676777 9.23744 0.676777 8.76256 0.96967 8.46967L3.59467 5.84467C3.88756 5.55178 4.36244 5.55178 4.65533 5.84467C4.94822 6.13756 4.94822 6.61244 4.65533 6.90533L3.31066 8.25L10.5 8.25C10.9142 8.25 11.25 8.58579 11.25 9C11.25 9.41421 10.9142 9.75 10.5 9.75L3.31066 9.75L4.65533 11.0947Z"
          fill="#9F9F9F"
          strokeWidth="0"
        />
      </g>
      <defs>
        <clipPath id="clip0_2_611">
          <rect
            width="18"
            height="18"
            fill="white"
            transform="translate(0 18) rotate(-90)"
          />
        </clipPath>
      </defs>
    </svg>
  );
};
export const NotePencilIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 30 30"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M14.9998 18.7333H11.2665V14.9999L22.4665 3.79993L26.1998 7.53326L14.9998 18.7333Z"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M19.6665 6.59993L23.3998 10.3333"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M25.2665 14.0666V24.3333C25.2665 24.5808 25.1682 24.8182 24.9931 24.9932C24.8181 25.1683 24.5807 25.2666 24.3332 25.2666H5.66649C5.41895 25.2666 5.18156 25.1683 5.00652 24.9932C4.83149 24.8182 4.73315 24.5808 4.73315 24.3333V5.66659C4.73315 5.41906 4.83149 5.18166 5.00652 5.00663C5.18156 4.83159 5.41895 4.73326 5.66649 4.73326H15.9332"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export const ChartLineUpIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 30 30"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M26.2 24.3333H3.80005V5.6666"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M24.3334 7.53325L15 16.8666L11.2667 13.1332L3.80005 20.5999"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M24.3334 12.1999V7.53325H19.6667"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export const DotedIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 34 8"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle cx="4" cy="4" r="4" fill="#C4C4C4" />
      <circle cx="17" cy="4" r="4" fill="#C4C4C4" />
      <path
        d="M34 4C34 6.20914 32.2091 8 30 8C27.7909 8 26 6.20914 26 4C26 1.79086 27.7909 0 30 0C32.2091 0 34 1.79086 34 4Z"
        fill="#C4C4C4"
      />
    </svg>
  );
};
export const DownArrowIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 16 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <circle cx="8" cy="8" r="8" fill="#FF3F3F" />
      <path
        d="M10.6667 6.66669L8.00008 9.33335L5.33341 6.66669"
        stroke="white"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export const UpArrowIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 16 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect
        x="16"
        y="16"
        width="16"
        height="16"
        rx="8"
        transform="rotate(-180 16 16)"
        fill="#A7FC84"
      />
      <path
        d="M5 9.5L8 6.5L11 9.5"
        stroke="#18191D"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export const PlusIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 14 14"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <rect
        x="5.74402"
        y="0.654785"
        width="2.2619"
        height="12.4405"
        rx="1.13095"
        fill="white"
      />
      <rect
        x="0.654785"
        y="8.00586"
        width="2.2619"
        height="12.4405"
        rx="1.13095"
        transform="rotate(-90 0.654785 8.00586)"
        fill="white"
      />
    </svg>
  );
};
export const LoginIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 16 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        fillRule="evenodd"
        d="M6 3.5a.5.5 0 0 1 .5-.5h8a.5.5 0 0 1 .5.5v9a.5.5 0 0 1-.5.5h-8a.5.5 0 0 1-.5-.5v-2a.5.5 0 0 0-1 0v2A1.5 1.5 0 0 0 6.5 14h8a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-8A1.5 1.5 0 0 0 5 3.5v2a.5.5 0 0 0 1 0v-2z"
      />
      <path
        fillRule="evenodd"
        d="M11.854 8.354a.5.5 0 0 0 0-.708l-3-3a.5.5 0 1 0-.708.708L10.293 7.5H1.5a.5.5 0 0 0 0 1h8.793l-2.147 2.146a.5.5 0 0 0 .708.708l3-3z"
      />
    </svg>
  );
};
export const SecurityIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 20 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M1.5 1.25V14.75C1.5 14.9489 1.42098 15.1397 1.28033 15.2803C1.13968 15.421 0.948912 15.5 0.75 15.5C0.551088 15.5 0.360322 15.421 0.21967 15.2803C0.0790178 15.1397 0 14.9489 0 14.75V1.25C0 1.05109 0.0790178 0.860322 0.21967 0.71967C0.360322 0.579018 0.551088 0.5 0.75 0.5C0.948912 0.5 1.13968 0.579018 1.28033 0.71967C1.42098 0.860322 1.5 1.05109 1.5 1.25ZM9.375 6.35938L7.5 6.96875V5C7.5 4.80109 7.42098 4.61032 7.28033 4.46967C7.13968 4.32902 6.94891 4.25 6.75 4.25C6.55109 4.25 6.36032 4.32902 6.21967 4.46967C6.07902 4.61032 6 4.80109 6 5V6.96875L4.125 6.35938C4.03213 6.3274 3.93377 6.31446 3.83579 6.32134C3.73781 6.32821 3.64222 6.35475 3.55473 6.39937C3.46723 6.44399 3.38962 6.50579 3.32652 6.58106C3.26343 6.65634 3.21615 6.74355 3.1875 6.8375C3.15541 6.931 3.14236 7.02999 3.14913 7.12861C3.15589 7.22724 3.18233 7.32351 3.22689 7.41176C3.27145 7.50001 3.33323 7.57844 3.40858 7.64243C3.48393 7.70643 3.57133 7.75469 3.66562 7.78437L5.54062 8.39375L4.37812 9.9875C4.32 10.0674 4.27826 10.1581 4.25528 10.2542C4.2323 10.3503 4.22854 10.45 4.24422 10.5476C4.2599 10.6452 4.29471 10.7387 4.34665 10.8227C4.39859 10.9068 4.46664 10.9798 4.54688 11.0375C4.70914 11.1525 4.91001 11.1992 5.10635 11.1676C5.30268 11.1361 5.4788 11.0288 5.59687 10.8688L6.75 9.275L7.90313 10.8688C8.0212 11.0288 8.19732 11.1361 8.39365 11.1676C8.58999 11.1992 8.79086 11.1525 8.95312 11.0375C9.03336 10.9798 9.10141 10.9068 9.15335 10.8227C9.20529 10.7387 9.2401 10.6452 9.25578 10.5476C9.27146 10.45 9.2677 10.3503 9.24472 10.2542C9.22174 10.1581 9.17999 10.0674 9.12188 9.9875L7.95938 8.39375L9.83437 7.78437C9.92867 7.75469 10.0161 7.70643 10.0914 7.64243C10.1668 7.57844 10.2285 7.50001 10.2731 7.41176C10.3177 7.32351 10.3441 7.22724 10.3509 7.12861C10.3576 7.02999 10.3446 6.931 10.3125 6.8375C10.2839 6.74355 10.2366 6.65634 10.1735 6.58106C10.1104 6.50579 10.0328 6.44399 9.94527 6.39937C9.85778 6.35475 9.76219 6.32821 9.66421 6.32134C9.56623 6.31446 9.46787 6.3274 9.375 6.35938ZM19.3125 6.8375C19.2839 6.74355 19.2366 6.65634 19.1735 6.58106C19.1104 6.50579 19.0328 6.44399 18.9453 6.39937C18.8578 6.35475 18.7622 6.32821 18.6642 6.32134C18.5662 6.31446 18.4679 6.3274 18.375 6.35938L16.5 6.96875V5C16.5 4.80109 16.421 4.61032 16.2803 4.46967C16.1397 4.32902 15.9489 4.25 15.75 4.25C15.5511 4.25 15.3603 4.32902 15.2197 4.46967C15.079 4.61032 15 4.80109 15 5V6.96875L13.125 6.35938C13.0321 6.3274 12.9338 6.31446 12.8358 6.32134C12.7378 6.32821 12.6422 6.35475 12.5547 6.39937C12.4672 6.44399 12.3896 6.50579 12.3265 6.58106C12.2634 6.65634 12.2161 6.74355 12.1875 6.8375C12.1554 6.931 12.1424 7.02999 12.1491 7.12861C12.1559 7.22724 12.1823 7.32351 12.2269 7.41176C12.2715 7.50001 12.3332 7.57844 12.4086 7.64243C12.4839 7.70643 12.5713 7.75469 12.6656 7.78437L14.5406 8.39375L13.3781 9.9875C13.32 10.0674 13.2783 10.1581 13.2553 10.2542C13.2323 10.3503 13.2285 10.45 13.2442 10.5476C13.2599 10.6452 13.2947 10.7387 13.3467 10.8227C13.3986 10.9068 13.4666 10.9798 13.5469 11.0375C13.7091 11.1525 13.91 11.1992 14.1063 11.1676C14.3027 11.1361 14.4788 11.0288 14.5969 10.8688L15.75 9.275L16.9031 10.8688C17.0212 11.0288 17.1973 11.1361 17.3937 11.1676C17.59 11.1992 17.7909 11.1525 17.9531 11.0375C18.0334 10.9798 18.1014 10.9068 18.1533 10.8227C18.2053 10.7387 18.2401 10.6452 18.2558 10.5476C18.2715 10.45 18.2677 10.3503 18.2447 10.2542C18.2217 10.1581 18.18 10.0674 18.1219 9.9875L16.9594 8.39375L18.8344 7.78437C18.9287 7.75469 19.0161 7.70643 19.0914 7.64243C19.1668 7.57844 19.2285 7.50001 19.2731 7.41176C19.3177 7.32351 19.3441 7.22724 19.3509 7.12861C19.3576 7.02999 19.3446 6.931 19.3125 6.8375Z"
        fill="white"
      />
    </svg>
  );
};
export const UserListIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 25 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M7.5 13.5C9.57107 13.5 11.25 11.8211 11.25 9.75C11.25 7.67893 9.57107 6 7.5 6C5.42893 6 3.75 7.67893 3.75 9.75C3.75 11.8211 5.42893 13.5 7.5 13.5Z"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M14.25 7.5H23.25"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M14.25 12H23.25"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M16.5 16.5H23.25"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M1.6875 18C2.01795 16.7094 2.76855 15.5655 3.82097 14.7486C4.87338 13.9317 6.16774 13.4883 7.5 13.4883C8.83226 13.4883 10.1266 13.9317 11.179 14.7486C12.2314 15.5655 12.982 16.7094 13.3125 18"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export const IdentificationCardIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M14.25 10.5H18"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M14.25 13.5H18"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M8.63477 13.5C9.87741 13.5 10.8848 12.4926 10.8848 11.25C10.8848 10.0074 9.87741 9 8.63477 9C7.39212 9 6.38477 10.0074 6.38477 11.25C6.38477 12.4926 7.39212 13.5 8.63477 13.5Z"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M5.72852 15.75C5.89374 15.1047 6.26904 14.5327 6.79525 14.1243C7.32146 13.7158 7.96864 13.4941 8.63477 13.4941C9.30089 13.4941 9.94808 13.7158 10.4743 14.1243C11.0005 14.5327 11.3758 15.1047 11.541 15.75"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M20.25 4.5H3.75C3.33579 4.5 3 4.83579 3 5.25V18.75C3 19.1642 3.33579 19.5 3.75 19.5H20.25C20.6642 19.5 21 19.1642 21 18.75V5.25C21 4.83579 20.6642 4.5 20.25 4.5Z"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export const UserFocusIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M16.875 3.75H19.5C19.6989 3.75 19.8897 3.82902 20.0303 3.96967C20.171 4.11032 20.25 4.30109 20.25 4.5V7.125"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M16.875 20.25H19.5C19.6989 20.25 19.8897 20.171 20.0303 20.0303C20.171 19.8897 20.25 19.6989 20.25 19.5V16.875"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M7.125 20.25H4.5C4.30109 20.25 4.11032 20.171 3.96967 20.0303C3.82902 19.8897 3.75 19.6989 3.75 19.5V16.875"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M7.125 3.75H4.5C4.30109 3.75 4.11032 3.82902 3.96967 3.96967C3.82902 4.11032 3.75 4.30109 3.75 4.5V7.125"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M12 13.5C13.6569 13.5 15 12.1569 15 10.5C15 8.84315 13.6569 7.5 12 7.5C10.3431 7.5 9 8.84315 9 10.5C9 12.1569 10.3431 13.5 12 13.5Z"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M7.02148 16.5C7.50091 15.5956 8.21765 14.8389 9.09471 14.3112C9.97177 13.7835 10.976 13.5046 11.9996 13.5046C13.0232 13.5046 14.0275 13.7835 14.9045 14.3112C15.7816 14.8389 16.4983 15.5956 16.9777 16.5"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export const MapPinIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M12 12.75C13.6569 12.75 15 11.4069 15 9.75C15 8.09315 13.6569 6.75 12 6.75C10.3431 6.75 9 8.09315 9 9.75C9 11.4069 10.3431 12.75 12 12.75Z"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M19.5 9.75C19.5 16.5 12 21.75 12 21.75C12 21.75 4.5 16.5 4.5 9.75C4.5 7.76088 5.29018 5.85322 6.6967 4.4467C8.10322 3.04018 10.0109 2.25 12 2.25C13.9891 2.25 15.8968 3.04018 17.3033 4.4467C18.7098 5.85322 19.5 7.76088 19.5 9.75V9.75Z"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export const CheckmarkIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 10 8"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path d="M3.138 5.68313L0.942666 3.625L0 4.50875L3.138 7.45062L9.60933 1.38375L8.66667 0.5L3.138 5.68313Z" />
    </svg>
  );
};
export const EyeClosedIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M18.8535 11.9343L21.0004 15.6375"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M14.4561 13.9968L15.1217 17.775"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M9.53477 13.9875L8.86914 17.7751"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M5.13711 11.9343L2.99023 15.6562"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M3 9.83447C4.575 11.7845 7.4625 14.2501 12 14.2501C16.5375 14.2501 19.425 11.7845 21 9.83447"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export const EyeIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M12 5.25C4.5 5.25 1.5 12 1.5 12C1.5 12 4.5 18.75 12 18.75C19.5 18.75 22.5 12 22.5 12C22.5 12 19.5 5.25 12 5.25Z"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M12 15.75C14.0711 15.75 15.75 14.0711 15.75 12C15.75 9.92893 14.0711 8.25 12 8.25C9.92893 8.25 8.25 9.92893 8.25 12C8.25 14.0711 9.92893 15.75 12 15.75Z"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export const CheckIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 25 18"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M23 2L9 16L2 9"
        strokeWidth="2.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export const TrashIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 35 35"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M29.0771 7.53857H5.38477"
        strokeWidth="2.15385"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M14 14V22.6154"
        strokeWidth="2.15385"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M20.4619 14V22.6154"
        strokeWidth="2.15385"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M26.9227 7.53857V28.0001C26.9227 28.2857 26.8092 28.5597 26.6073 28.7616C26.4053 28.9636 26.1314 29.077 25.8458 29.077H8.61501C8.32939 29.077 8.05547 28.9636 7.85351 28.7616C7.65155 28.5597 7.53809 28.2857 7.53809 28.0001V7.53857"
        strokeWidth="2.15385"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M22.6149 7.53816V5.38432C22.6149 4.81308 22.388 4.26524 21.9841 3.86132C21.5802 3.45739 21.0323 3.23047 20.4611 3.23047H13.9995C13.4283 3.23047 12.8805 3.45739 12.4766 3.86132C12.0726 4.26524 11.8457 4.81308 11.8457 5.38432V7.53816"
        strokeWidth="2.15385"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export const SimpleDotedIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 25 4"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M12 4C13.1046 4 14 3.10457 14 2C14 0.895431 13.1046 0 12 0C10.8954 0 10 0.895431 10 2C10 3.10457 10.8954 4 12 4Z"
        fill="white"
        strokeWidth="0"
      />
      <path
        d="M23 4C24.1046 4 25 3.10457 25 2C25 0.895431 24.1046 0 23 0C21.8954 0 21 0.895431 21 2C21 3.10457 21.8954 4 23 4Z"
        fill="white"
        strokeWidth="0"
      />
      <path
        d="M2 4C3.10457 4 4 3.10457 4 2C4 0.895431 3.10457 0 2 0C0.895431 0 0 0.895431 0 2C0 3.10457 0.895431 4 2 4Z"
        fill="white"
        strokeWidth="0"
      />
    </svg>
  );
};
export const SimpleTrashIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M16.875 4.375H3.125"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M6.875 1.875H13.125"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M15.625 4.375V16.25C15.625 16.4158 15.5592 16.5747 15.4419 16.6919C15.3247 16.8092 15.1658 16.875 15 16.875H5C4.83424 16.875 4.67527 16.8092 4.55806 16.6919C4.44085 16.5747 4.375 16.4158 4.375 16.25V4.375"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export const SimpleCheckIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 16 12"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path d="M5.6 7.5L2.4 4.5L0 6.75L5.6 12L16 2.25L13.6 0L5.6 7.5Z" />
    </svg>
  );
};
export const MessageIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 18 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path d="M15.875 0.125H2.125C1.79348 0.125 1.47554 0.256696 1.24112 0.491116C1.0067 0.725537 0.875 1.04348 0.875 1.375V11.375C0.875 11.7065 1.0067 12.0245 1.24112 12.2589C1.47554 12.4933 1.79348 12.625 2.125 12.625H6.77344L7.92969 14.5547C8.04093 14.7391 8.19792 14.8916 8.38544 14.9975C8.57296 15.1034 8.78465 15.159 9 15.159C9.21535 15.159 9.42704 15.1034 9.61456 14.9975C9.80208 14.8916 9.95907 14.7391 10.0703 14.5547L11.2266 12.625H15.875C16.2065 12.625 16.5245 12.4933 16.7589 12.2589C16.9933 12.0245 17.125 11.7065 17.125 11.375V1.375C17.125 1.04348 16.9933 0.725537 16.7589 0.491116C16.5245 0.256696 16.2065 0.125 15.875 0.125ZM5.25 7.3125C5.06458 7.3125 4.88332 7.25752 4.72915 7.1545C4.57498 7.05149 4.45482 6.90507 4.38386 6.73377C4.31291 6.56246 4.29434 6.37396 4.33051 6.1921C4.36669 6.01025 4.45598 5.8432 4.58709 5.71209C4.7182 5.58098 4.88525 5.49169 5.0671 5.45551C5.24896 5.41934 5.43746 5.43791 5.60877 5.50886C5.78007 5.57982 5.92649 5.69998 6.0295 5.85415C6.13252 6.00832 6.1875 6.18958 6.1875 6.375C6.1875 6.62364 6.08873 6.8621 5.91291 7.03791C5.7371 7.21373 5.49864 7.3125 5.25 7.3125ZM9 7.3125C8.81458 7.3125 8.63332 7.25752 8.47915 7.1545C8.32498 7.05149 8.20482 6.90507 8.13386 6.73377C8.06291 6.56246 8.04434 6.37396 8.08051 6.1921C8.11669 6.01025 8.20598 5.8432 8.33709 5.71209C8.4682 5.58098 8.63525 5.49169 8.8171 5.45551C8.99896 5.41934 9.18746 5.43791 9.35876 5.50886C9.53007 5.57982 9.67649 5.69998 9.7795 5.85415C9.88252 6.00832 9.9375 6.18958 9.9375 6.375C9.9375 6.62364 9.83873 6.8621 9.66291 7.03791C9.4871 7.21373 9.24864 7.3125 9 7.3125ZM12.75 7.3125C12.5646 7.3125 12.3833 7.25752 12.2292 7.1545C12.075 7.05149 11.9548 6.90507 11.8839 6.73377C11.8129 6.56246 11.7943 6.37396 11.8305 6.1921C11.8667 6.01025 11.956 5.8432 12.0871 5.71209C12.2182 5.58098 12.3852 5.49169 12.5671 5.45551C12.749 5.41934 12.9375 5.43791 13.1088 5.50886C13.2801 5.57982 13.4265 5.69998 13.5295 5.85415C13.6325 6.00832 13.6875 6.18958 13.6875 6.375C13.6875 6.62364 13.5887 6.8621 13.4129 7.03791C13.2371 7.21373 12.9986 7.3125 12.75 7.3125Z" />
    </svg>
  );
};
export const StarFillIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 12 12"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M11.3584 4.0787L8.12144 3.60845L6.67319 0.675203C6.41969 0.162953 5.58119 0.162953 5.32769 0.675203L3.88019 3.60845L0.642439 4.0787C0.0296886 4.16795 -0.218561 4.92395 0.226939 5.35895L2.56994 7.64195L2.01719 10.8662C1.91294 11.4767 2.55494 11.9455 3.10544 11.6567L6.00044 10.135L8.89619 11.6575C9.44219 11.9432 10.0894 11.482 9.98444 10.867L9.43169 7.6427L11.7747 5.3597C12.2194 4.92395 11.9712 4.16795 11.3584 4.0787Z"
        fill="#FFC246"
      />
    </svg>
  );
};
export const StarEmptyIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 12 12"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M11.3584 4.0787L8.12144 3.60845L6.67319 0.675203C6.41969 0.162953 5.58119 0.162953 5.32769 0.675203L3.88019 3.60845L0.642439 4.0787C0.0296886 4.16795 -0.218561 4.92395 0.226939 5.35895L2.56994 7.64195L2.01719 10.8662C1.91294 11.4767 2.55494 11.9455 3.10544 11.6567L6.00044 10.135L8.89619 11.6575C9.44219 11.9432 10.0894 11.482 9.98444 10.867L9.43169 7.6427L11.7747 5.3597C12.2194 4.92395 11.9712 4.16795 11.3584 4.0787Z"
        fill="#808191"
      />
    </svg>
  );
};
export const CameraIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 16 15"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path d="M2.5 2.66699V0.666992H3.83333V2.66699H5.83333V4.00033H3.83333V6.00033H2.5V4.00033H0.5V2.66699H2.5ZM4.5 6.66699V4.66699H6.5V2.66699H11.1667L12.3867 4.00033H14.5C15.2333 4.00033 15.8333 4.60033 15.8333 5.33366V13.3337C15.8333 14.067 15.2333 14.667 14.5 14.667H3.83333C3.1 14.667 2.5 14.067 2.5 13.3337V6.66699H4.5ZM9.16667 12.667C11.0067 12.667 12.5 11.1737 12.5 9.33366C12.5 7.49366 11.0067 6.00033 9.16667 6.00033C7.32667 6.00033 5.83333 7.49366 5.83333 9.33366C5.83333 11.1737 7.32667 12.667 9.16667 12.667ZM7.03333 9.33366C7.03333 10.5137 7.98667 11.467 9.16667 11.467C10.3467 11.467 11.3 10.5137 11.3 9.33366C11.3 8.15366 10.3467 7.20033 9.16667 7.20033C7.98667 7.20033 7.03333 8.15366 7.03333 9.33366Z" />
    </svg>
  );
};
export const CameraLineIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 23 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M18.6875 19.5H4.3125C3.93125 19.5 3.56562 19.342 3.29603 19.0607C3.02645 18.7794 2.875 18.3978 2.875 18V7.5C2.875 7.10218 3.02645 6.72064 3.29603 6.43934C3.56562 6.15804 3.93125 6 4.3125 6H7.1875L8.625 3.75H14.375L15.8125 6H18.6875C19.0687 6 19.4344 6.15804 19.704 6.43934C19.9735 6.72064 20.125 7.10218 20.125 7.5V18C20.125 18.3978 19.9735 18.7794 19.704 19.0607C19.4344 19.342 19.0687 19.5 18.6875 19.5Z"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M11.5 15.75C13.2863 15.75 14.7344 14.239 14.7344 12.375C14.7344 10.511 13.2863 9 11.5 9C9.7137 9 8.26562 10.511 8.26562 12.375C8.26562 14.239 9.7137 15.75 11.5 15.75Z"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export const SmileyIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M10 17.5C14.1421 17.5 17.5 14.1421 17.5 10C17.5 5.85786 14.1421 2.5 10 2.5C5.85786 2.5 2.5 5.85786 2.5 10C2.5 14.1421 5.85786 17.5 10 17.5Z"
        stroke="white"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M7.1875 9.375C7.70527 9.375 8.125 8.95527 8.125 8.4375C8.125 7.91973 7.70527 7.5 7.1875 7.5C6.66973 7.5 6.25 7.91973 6.25 8.4375C6.25 8.95527 6.66973 9.375 7.1875 9.375Z"
        fill="white"
      />
      <path
        d="M12.8125 9.375C13.3303 9.375 13.75 8.95527 13.75 8.4375C13.75 7.91973 13.3303 7.5 12.8125 7.5C12.2947 7.5 11.875 7.91973 11.875 8.4375C11.875 8.95527 12.2947 9.375 12.8125 9.375Z"
        fill="white"
      />
      <path
        d="M13.25 11.875C12.9196 12.4442 12.4455 12.9167 11.8751 13.2451C11.3048 13.5735 10.6582 13.7464 10 13.7464C9.34184 13.7464 8.69523 13.5735 8.12486 13.2451C7.5545 12.9167 7.0804 12.4442 6.75 11.875"
        stroke="white"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export const LinkSimpleIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M7.35156 12.6484L12.6484 7.34375"
        stroke="white"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M11.3281 13.9766L9.11719 16.1875C8.76888 16.5358 8.35538 16.8121 7.90029 17.0006C7.4452 17.1891 6.95743 17.2861 6.46485 17.2861C5.47003 17.2861 4.51595 16.8909 3.8125 16.1875C3.10906 15.4841 2.71387 14.53 2.71387 13.5352C2.71387 12.5403 3.10906 11.5863 3.8125 10.8828L6.02344 8.67188"
        stroke="white"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M13.9766 11.3281L16.1875 9.11719C16.8909 8.41375 17.2861 7.45967 17.2861 6.46485C17.2861 5.47003 16.8909 4.51595 16.1875 3.8125C15.4841 3.10906 14.53 2.71387 13.5352 2.71387C12.5403 2.71387 11.5863 3.10906 10.8828 3.8125L8.67188 6.02344"
        stroke="white"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export const UploadIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 16 16"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path d="M9 4V11H7V4H4L8 0L12 4H9Z" />
      <path d="M15.0005 16H1.00053C0.713531 16 0.440531 15.877 0.250531 15.662C0.0605311 15.447 -0.0274689 15.161 0.00753112 14.876L1.00753 6.876C1.07053 6.375 1.49653 6 2.00053 6H5.00053V8H2.88353L2.13353 14H13.8675L13.1175 8H11.0005V6H14.0005C14.5045 6 14.9305 6.375 14.9925 6.876L15.9925 14.876C16.0285 15.161 15.9395 15.447 15.7495 15.662C15.5605 15.877 15.2875 16 15.0005 16Z" />
    </svg>
  );
};
export const CopyIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 24 24"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        opacity="0.2"
        d="M15.75 8.25V15.75H20.25V3.75H8.25V8.25H15.75Z"
        fill="#838383"
      />
      <path
        d="M15.75 15.75H20.25V3.75H8.25V8.25"
        stroke="#838383"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M15.75 8.25H3.75V20.25H15.75V8.25Z"
        stroke="#838383"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
};
export const TwitterShareIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 22 19"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M21.0346 4.28437L18.2034 7.10625C17.6409 13.6594 12.1096 18.75 5.50025 18.75C4.14087 18.75 3.01587 18.5344 2.16275 18.1125C1.47837 17.7656 1.19712 17.4 1.12212 17.2875C1.06007 17.1932 1.02009 17.0862 1.00515 16.9744C0.990208 16.8625 1.0007 16.7487 1.03584 16.6415C1.07099 16.5343 1.12988 16.4363 1.20812 16.355C1.28636 16.2737 1.38195 16.2111 1.48775 16.1719C1.5065 16.1625 3.719 15.3187 5.15337 13.6969C4.26382 13.0635 3.48195 12.2911 2.83775 11.4094C1.55337 9.66562 0.194 6.6375 1.00962 2.11875C1.03526 1.98441 1.09671 1.85949 1.18747 1.75718C1.27822 1.65487 1.39493 1.57897 1.52525 1.5375C1.65599 1.49469 1.79598 1.48866 1.92991 1.52008C2.06385 1.55149 2.18656 1.61914 2.28462 1.71562C2.31275 1.75312 5.43462 4.82812 9.25025 5.82187V5.25C9.25393 4.65535 9.3747 4.06725 9.60567 3.51928C9.83664 2.97132 10.1733 2.47421 10.5964 2.05634C11.0195 1.63847 11.5207 1.30804 12.0715 1.08389C12.6223 0.85975 13.2119 0.746291 13.8065 0.749996C14.587 0.761127 15.3512 0.974229 16.0248 1.36854C16.6985 1.76285 17.2584 2.32492 17.6503 3H20.5002C20.6483 2.99953 20.7932 3.04291 20.9167 3.12466C21.0401 3.20641 21.1366 3.32287 21.194 3.45937C21.248 3.5979 21.2617 3.74891 21.2335 3.8949C21.2053 4.0409 21.1364 4.17593 21.0346 4.28437Z"
        fill="white"
      />
    </svg>
  );
};
export const FacebookShareIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 20 20"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M19.7498 10C19.745 12.3821 18.8708 14.6805 17.2913 16.4636C15.7119 18.2468 13.5358 19.392 11.1717 19.6844C11.119 19.6896 11.0657 19.6838 11.0153 19.6674C10.9649 19.651 10.9184 19.6244 10.8788 19.5891C10.8392 19.5539 10.8073 19.5109 10.7851 19.4627C10.7629 19.4146 10.7509 19.3624 10.7498 19.3094V12.25H12.9998C13.1024 12.2502 13.2039 12.2294 13.2981 12.1888C13.3923 12.1482 13.4772 12.0887 13.5475 12.014C13.6178 11.9393 13.672 11.851 13.7068 11.7546C13.7416 11.6581 13.7563 11.5555 13.7498 11.4531C13.7333 11.2592 13.6437 11.0788 13.4993 10.9483C13.3549 10.8178 13.1663 10.7469 12.9717 10.75H10.7498V8.50001C10.7498 8.10218 10.9079 7.72065 11.1892 7.43935C11.4705 7.15804 11.852 7.00001 12.2498 7.00001H13.7498C13.8524 7.00021 13.9539 6.97937 14.0481 6.93878C14.1423 6.89819 14.2272 6.83872 14.2975 6.76403C14.3678 6.68935 14.422 6.60104 14.4568 6.50456C14.4916 6.40808 14.5063 6.30549 14.4998 6.20313C14.4833 6.0092 14.3937 5.82878 14.2493 5.69828C14.1049 5.56778 13.9163 5.49692 13.7217 5.50001H12.2498C11.4542 5.50001 10.6911 5.81608 10.1285 6.37869C9.56592 6.9413 9.24985 7.70436 9.24985 8.50001V10.75H6.99985C6.89729 10.7498 6.79577 10.7706 6.70158 10.8112C6.60739 10.8518 6.52253 10.9113 6.45223 10.986C6.38194 11.0607 6.32771 11.149 6.2929 11.2455C6.25809 11.3419 6.24344 11.4445 6.24985 11.5469C6.26644 11.7408 6.35598 11.9212 6.5004 12.0517C6.64481 12.1822 6.83336 12.2531 7.02797 12.25H9.24985V19.3094C9.25011 19.3619 9.23932 19.414 9.21818 19.4621C9.19703 19.5102 9.166 19.5534 9.12711 19.5887C9.08821 19.6241 9.04231 19.6509 8.99239 19.6674C8.94248 19.6838 8.88965 19.6896 8.83735 19.6844C3.88735 19.0844 0.0623491 14.7813 0.259224 9.63438C0.369739 7.09262 1.4694 4.69472 3.32347 2.95254C5.17755 1.21036 7.63917 0.261906 10.1829 0.309624C12.7266 0.357342 15.1509 1.39745 16.9384 3.20795C18.7258 5.01844 19.7347 7.45588 19.7498 10Z"
        fill="white"
      />
    </svg>
  );
};
export const InstagramIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g clipPath="url(#clip0_207_2346)">
        <path
          d="M0.0185547 10.7333C0.0185547 6.93673 0.0185547 5.03843 0.769132 3.5935C1.40164 2.37588 2.39444 1.38308 3.61206 0.750577C5.05698 0 6.95528 0 10.7519 0H21.2852C25.0818 0 26.9801 0 28.425 0.750577C29.6427 1.38308 30.6355 2.37588 31.268 3.5935C32.0186 5.03843 32.0186 6.93673 32.0186 10.7333V21.2667C32.0186 25.0633 32.0186 26.9616 31.268 28.4065C30.6355 29.6241 29.6427 30.6169 28.425 31.2494C26.9801 32 25.0818 32 21.2852 32H10.7519C6.95528 32 5.05698 32 3.61206 31.2494C2.39444 30.6169 1.40164 29.6241 0.769132 28.4065C0.0185547 26.9616 0.0185547 25.0633 0.0185547 21.2667V10.7333Z"
          fill="url(#paint0_radial_207_2346)"
        />
        <path
          d="M0.0185547 10.7333C0.0185547 6.93673 0.0185547 5.03843 0.769132 3.5935C1.40164 2.37588 2.39444 1.38308 3.61206 0.750577C5.05698 0 6.95528 0 10.7519 0H21.2852C25.0818 0 26.9801 0 28.425 0.750577C29.6427 1.38308 30.6355 2.37588 31.268 3.5935C32.0186 5.03843 32.0186 6.93673 32.0186 10.7333V21.2667C32.0186 25.0633 32.0186 26.9616 31.268 28.4065C30.6355 29.6241 29.6427 30.6169 28.425 31.2494C26.9801 32 25.0818 32 21.2852 32H10.7519C6.95528 32 5.05698 32 3.61206 31.2494C2.39444 30.6169 1.40164 29.6241 0.769132 28.4065C0.0185547 26.9616 0.0185547 25.0633 0.0185547 21.2667V10.7333Z"
          fill="url(#paint1_radial_207_2346)"
        />
        <path
          d="M16.0003 4.36328C12.8401 4.36328 12.4435 4.3771 11.2023 4.43358C9.9636 4.49031 9.11805 4.68643 8.37819 4.97419C7.61288 5.2714 6.96369 5.66898 6.31692 6.31601C5.66967 6.9628 5.2721 7.61201 4.97393 8.3771C4.68545 9.11722 4.4891 9.96304 4.43334 11.2013C4.37783 12.4426 4.36328 12.8394 4.36328 15.9996C4.36328 19.1599 4.37734 19.5553 4.43358 20.7965C4.49055 22.0353 4.68667 22.8809 4.97417 23.6207C5.27162 24.3861 5.66918 25.0353 6.31619 25.6821C6.96272 26.3293 7.61191 26.7279 8.37674 27.0251C9.11708 27.3129 9.96287 27.509 11.2014 27.5657C12.4426 27.6222 12.8389 27.636 15.9988 27.636C19.1592 27.636 19.5546 27.6222 20.7958 27.5657C22.0345 27.509 22.881 27.3129 23.6214 27.0251C24.3864 26.7279 25.0347 26.3293 25.6812 25.6821C26.3284 25.0353 26.726 24.3861 27.0242 23.621C27.3102 22.8809 27.5066 22.035 27.5648 20.7967C27.6205 19.5555 27.6351 19.1599 27.6351 15.9996C27.6351 12.8394 27.6205 12.4428 27.5648 11.2016C27.5066 9.9628 27.3102 9.11722 27.0242 8.37734C26.726 7.61201 26.3284 6.9628 25.6812 6.31601C25.0339 5.66874 24.3867 5.27116 23.6206 4.97419C22.8788 4.68643 22.0328 4.49031 20.7941 4.43358C19.5529 4.3771 19.1577 4.36328 15.9966 4.36328H16.0003ZM14.9564 6.46025C15.2662 6.45977 15.6119 6.46025 16.0003 6.46025C19.1071 6.46025 19.4753 6.4714 20.7022 6.52716C21.8367 6.57904 22.4524 6.76861 22.8626 6.92789C23.4056 7.1388 23.7928 7.39092 24.1998 7.79819C24.607 8.20546 24.8591 8.59334 25.0705 9.13637C25.2298 9.54607 25.4196 10.1618 25.4712 11.2964C25.527 12.523 25.5391 12.8915 25.5391 15.997C25.5391 19.1024 25.527 19.4709 25.4712 20.6976C25.4194 21.8321 25.2298 22.4479 25.0705 22.8576C24.8596 23.4006 24.607 23.7873 24.1998 24.1943C23.7925 24.6016 23.4059 24.8537 22.8626 25.0646C22.4529 25.2246 21.8367 25.4137 20.7022 25.4656C19.4756 25.5213 19.1071 25.5335 16.0003 25.5335C12.8932 25.5335 12.525 25.5213 11.2983 25.4656C10.1638 25.4132 9.54809 25.2236 9.13768 25.0644C8.59467 24.8535 8.2068 24.6013 7.79954 24.1941C7.39228 23.7868 7.14017 23.3999 6.92878 22.8566C6.76951 22.4469 6.5797 21.8312 6.52806 20.6966C6.47231 19.4699 6.46116 19.1015 6.46116 15.9941C6.46116 12.8867 6.47231 12.5201 6.52806 11.2935C6.57994 10.1589 6.76951 9.54316 6.92878 9.13298C7.13968 8.58995 7.39228 8.20207 7.79954 7.7948C8.2068 7.38752 8.59467 7.1354 9.13768 6.92401C9.54785 6.76401 10.1638 6.57492 11.2983 6.5228C12.3718 6.47431 12.7878 6.45977 14.9564 6.45734V6.46025ZM22.2115 8.39237C21.4406 8.39237 20.8151 9.0171 20.8151 9.78825C20.8151 10.5592 21.4406 11.1846 22.2115 11.1846C22.9824 11.1846 23.6078 10.5592 23.6078 9.78825C23.6078 9.01734 22.9824 8.39189 22.2115 8.39189V8.39237ZM16.0003 10.0239C12.7002 10.0239 10.0247 12.6995 10.0247 15.9996C10.0247 19.2998 12.7002 21.9742 16.0003 21.9742C19.3003 21.9742 21.9749 19.2998 21.9749 15.9996C21.9749 12.6995 19.3 10.0239 16 10.0239H16.0003ZM16.0003 12.1209C18.1423 12.1209 19.8789 13.8573 19.8789 15.9996C19.8789 18.1417 18.1423 19.8784 16.0003 19.8784C13.858 19.8784 12.1216 18.1417 12.1216 15.9996C12.1216 13.8573 13.858 12.1209 16.0003 12.1209Z"
          fill="white"
        />
      </g>
      <defs>
        <radialGradient
          id="paint0_radial_207_2346"
          cx="0"
          cy="0"
          r="1"
          gradientUnits="userSpaceOnUse"
          gradientTransform="translate(8.51859 34.4647) rotate(-90) scale(31.7144 29.4969)"
        >
          <stop stopColor="#FFDD55" />
          <stop offset="0.1" stopColor="#FFDD55" />
          <stop offset="0.5" stopColor="#FF543E" />
          <stop offset="1" stopColor="#C837AB" />
        </radialGradient>
        <radialGradient
          id="paint1_radial_207_2346"
          cx="0"
          cy="0"
          r="1"
          gradientUnits="userSpaceOnUse"
          gradientTransform="translate(-5.34161 2.30523) rotate(78.6806) scale(14.1765 58.4359)"
        >
          <stop stopColor="#3771C8" />
          <stop offset="0.128" stopColor="#3771C8" />
          <stop offset="1" stopColor="#6600FF" stopOpacity="0" />
        </radialGradient>
        <clipPath id="clip0_207_2346">
          <rect width="32" height="32" fill="white" />
        </clipPath>
      </defs>
    </svg>
  );
};
export const TwitterIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        d="M0 10.7333C0 6.93673 0 5.03843 0.750577 3.5935C1.38308 2.37588 2.37588 1.38308 3.5935 0.750577C5.03843 0 6.93673 0 10.7333 0H21.2667C25.0633 0 26.9616 0 28.4065 0.750577C29.6241 1.38308 30.6169 2.37588 31.2494 3.5935C32 5.03843 32 6.93673 32 10.7333V21.2667C32 25.0633 32 26.9616 31.2494 28.4065C30.6169 29.6241 29.6241 30.6169 28.4065 31.2494C26.9616 32 25.0633 32 21.2667 32H10.7333C6.93673 32 5.03843 32 3.5935 31.2494C2.37588 30.6169 1.38308 29.6241 0.750577 28.4065C0 26.9616 0 25.0633 0 21.2667V10.7333Z"
        fill="#1EA1F2"
      />
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M24.8821 12.1014C24.8899 12.3013 24.8925 12.5011 24.8925 12.701C24.8925 18.7606 20.6298 25.7561 12.8348 25.7561C10.4404 25.7561 8.21385 24.993 6.33789 23.6938C6.6695 23.7302 7.00628 23.7575 7.34822 23.7575C9.33357 23.7575 11.1622 23.0215 12.6126 21.7859C10.7582 21.7586 9.19232 20.4232 8.65227 18.6062C8.91153 18.6607 9.17852 18.688 9.45156 18.688C9.83657 18.688 10.2104 18.6336 10.5687 18.5246C8.62813 18.1066 7.16649 16.2534 7.16649 14.0275C7.16649 14.0003 7.16649 13.9912 7.16649 13.973C7.7384 14.3091 8.393 14.518 9.08808 14.5452C7.94942 13.7185 7.20092 12.3104 7.20092 10.7205C7.20092 9.88469 7.40936 9.09426 7.77628 8.41289C9.86585 11.1929 12.9899 13.019 16.5118 13.2098C16.4395 12.8736 16.4024 12.5194 16.4024 12.1651C16.4024 9.63039 18.2999 7.57715 20.641 7.57715C21.8598 7.57715 22.9605 8.13141 23.7331 9.02173C24.7004 8.82187 25.6065 8.44032 26.4265 7.9134C26.1087 8.98542 25.4377 9.88464 24.5609 10.4479C25.4187 10.3389 26.237 10.0938 26.9958 9.73039C26.4265 10.648 25.7099 11.4564 24.8821 12.1014Z"
        fill="white"
      />
    </svg>
  );
};
export const TelegramIcon = ({ width, height }) => {
  return (
    <svg
      width={width}
      height={height}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
    >
      <g clipPath="url(#clip0_207_2352)">
        <path
          d="M0 10.7333C0 6.93673 0 5.03843 0.750577 3.5935C1.38308 2.37588 2.37588 1.38308 3.5935 0.750577C5.03843 0 6.93673 0 10.7333 0H21.2667C25.0633 0 26.9616 0 28.4065 0.750577C29.6241 1.38308 30.6169 2.37588 31.2494 3.5935C32 5.03843 32 6.93673 32 10.7333V21.2667C32 25.0633 32 26.9616 31.2494 28.4065C30.6169 29.6241 29.6241 30.6169 28.4065 31.2494C26.9616 32 25.0633 32 21.2667 32H10.7333C6.93673 32 5.03843 32 3.5935 31.2494C2.37588 30.6169 1.38308 29.6241 0.750577 28.4065C0 26.9616 0 25.0633 0 21.2667V10.7333Z"
          fill="url(#paint0_linear_207_2352)"
        />
        <path
          d="M12.3337 24.5003C11.6857 24.5003 11.7958 24.2557 11.5724 23.6387L9.66699 17.368L24.3337 8.66699"
          fill="#C8DAEA"
        />
        <path
          d="M12.333 24.5002C12.833 24.5002 13.0539 24.2715 13.333 24.0002L15.9997 21.4072L12.6733 19.4014"
          fill="#A9C9DD"
        />
        <path
          d="M12.6735 19.4016L20.7335 25.3564C21.6533 25.8639 22.3171 25.6011 22.5462 24.5025L25.827 9.04199C26.1629 7.69529 25.3137 7.08449 24.4338 7.48396L5.16879 14.9125C3.85378 15.4399 3.86144 16.1736 4.92909 16.5005L9.87293 18.0435L21.3184 10.8227C21.8587 10.495 22.3546 10.6712 21.9476 11.0324"
          fill="url(#paint1_linear_207_2352)"
        />
      </g>
      <defs>
        <linearGradient
          id="paint0_linear_207_2352"
          x1="21.3344"
          y1="5.3344"
          x2="13.3344"
          y2="24"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#37AEE2" />
          <stop offset="1" stopColor="#1E96C8" />
        </linearGradient>
        <linearGradient
          id="paint1_linear_207_2352"
          x1="18.501"
          y1="15.333"
          x2="21.6308"
          y2="22.4552"
          gradientUnits="userSpaceOnUse"
        >
          <stop stopColor="#EFF7FC" />
          <stop offset="1" stopColor="white" />
        </linearGradient>
        <clipPath id="clip0_207_2352">
          <rect width="32" height="32" fill="white" />
        </clipPath>
      </defs>
    </svg>
  );
};
