import React from 'react'
import StakeScallopPage from './stakescallopPage'

function StakeScallopComponent() {
  return (
    <>
      <StakeScallopPage />
    </>
  )
}

export default StakeScallopComponent
