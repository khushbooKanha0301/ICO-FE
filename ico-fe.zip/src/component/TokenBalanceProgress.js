import { useDispatch, useSelector } from "react-redux";
import { userDetails, userGetFullDetails } from "../store/slices/AuthSlice";
import React from "react";
import { Col, Row } from "react-bootstrap";

//this component is used for token balance progess bar
export const TokenBalanceProgress = () => {
  const dispatch = useDispatch();
  const { tokenData } = useSelector((state) => state?.currenyReducer);
  const userData = useSelector(userDetails);
  const userDetailsAll = useSelector(userGetFullDetails);
  let authToken = userData.authToken ? userData.authToken : null;

  return (
    <>
      <div className="token-balance">
        <div className="token-avatar"></div>
        <div>
          <div className="token-text">Token Balance</div>
          <div className="token-amount">
            {authToken &&
            userDetailsAll?.is_2FA_login_verified === true &&
            tokenData &&
            tokenData?.totalUserCount
              ? tokenData?.totalUserCount
              : 0}
            <span>MID</span>
          </div>
        </div>
      </div>
      <h5>Your Contribution</h5>
      <Row>
        <Col>
          <div className="contribution-amount">{tokenData?.gbpCount}</div>
          <div className="contribution-label">
            <img
              className="currency-flag"
              src={require("../content/images/gbp-icon-resized.png")}
              alt="Bitcoin"
              style={{ width: "16px", height: "16px" }}
            />
            GBP
          </div>
        </Col>
        <Col>
          <div className="contribution-amount">{tokenData?.eurCount}</div>
          <div className="contribution-label">
            <img
              className="currency-flag"
              src={require("../content/images/eur-icon.png")}
              alt="Bitcoin"
              style={{ width: "16px", height: "16px" }}
            />
            EUR
          </div>
        </Col>
        <Col>
          <div className="contribution-amount">{tokenData?.audCount}</div>
          <div className="contribution-label">
            <img
              className="currency-flag"
              src={require("../content/images/aud-icon.png")}
              alt="Bitcoin"
              style={{ width: "16px", height: "16px" }}
            />
            AUD
          </div>
        </Col>
      </Row>
    </>
  );
};

export default TokenBalanceProgress;
