import React from 'react'
import IcoDistributionPage from './IcodistributionPage'

function IcoDistributionComponent() {
  return (
    <>
      <IcoDistributionPage />
    </>
  )
}

export default IcoDistributionComponent
