import React from 'react'
import DashboardPage from './dashboardPage'

function DashboardComponent() {
  return (
    <>
      <DashboardPage />
    </>
  )
}

export default DashboardComponent
