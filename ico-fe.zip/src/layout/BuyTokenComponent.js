import React from 'react'
import BuyToken from './buytokenPage'

function BuyTokenComponent() {
  return (
    <>
      <BuyToken />
    </>
  )
}

export default BuyTokenComponent
