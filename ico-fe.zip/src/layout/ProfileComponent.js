import React from 'react'
import ProfilePage from './profilePage'

function ProfileComponent() {
  return (
    <>
      <ProfilePage />
    </>
  )
}

export default ProfileComponent
