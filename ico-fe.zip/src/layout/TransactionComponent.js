import React from 'react'
import TransactionPage from './transactionPage'

function TransactionComponent() {
  return (
    <>
      <TransactionPage />
    </>
  )
}

export default TransactionComponent
